import React from 'react';
import { Navbar, Nav, Form, FormControl, Button } from 'react-bootstrap';

function Header() {
    return (
        <>
            <Navbar bg="dark" variant="dark">
                <Navbar.Brand>Accenture</Navbar.Brand>
                <Nav className="mr-auto">
                    <Nav.Link >Home</Nav.Link>
                </Nav>
                <Form inline className='d-none d-sm-block'>
                    <FormControl type="text" placeholder="Search" className="mr-sm-2" />
                    <Button variant="outline-info">Search</Button>
                </Form>
            </Navbar>

            <Navbar bg="light" variant="light" className='email-border-bottom'>
                <Navbar.Brand>Outlook</Navbar.Brand>
            </Navbar>
        </>
    )
}

export default Header;